﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void txtPeso_Validated_1(object sender, EventArgs e)
        {
            
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Text = string.Empty;
            txtIMC.Text = "";
            txtClasse.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura == 0)
            {
                MessageBox.Show("Altura inválido");
                txtAltura.Focus();
            }

            else if (!Double.TryParse(txtPeso.Text, out peso) || peso == 0)
            {
                MessageBox.Show("Peso inválido");
                txtPeso.Focus();
            }

            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc,1);
            txtIMC.Text = imc.ToString("F2");

            if (imc < 18.5)
            {
                txtClasse.Text = "MAGREZA";
            }
            else if (imc <= 24.9)
            {
                txtClasse.Text = "NORMAL";
            }
            else if (imc <= 29.9)
            {
                txtClasse.Text = "SOBREPESO";
            }
            else if (imc <= 39.9)
            {
                txtClasse.Text = "OBESIDADE";
            }
            else
            {
                txtClasse.Text = "OBESIDADE GRAVE";
            }
        }
    }
}
