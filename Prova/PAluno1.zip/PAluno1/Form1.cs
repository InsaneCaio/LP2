﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[5,3];
            double[] mediaAluno = new double[5];
            double mediaGeral = 0;
            string auxiliar;

            for (int i = 0; i < 5; i++)
            {
                mediaAluno[i] = 0;
                for (int j = 0; j < 3; j++)
                {
                    if (!Double.TryParse(auxiliar = Interaction.InputBox($"Digite a nota do professor {j+1}: ", $"Notas do Aluno {i+1}"), out notas[i, j]) || notas[i,j] < 0 || notas[i,j] > 10){
                        MessageBox.Show("Nota Inválida");
                        j--;
                    }
                    else
                    {
                        mediaAluno[i] += notas[i, j];
                    }

                }
                mediaAluno[i] /= 3;
                mediaGeral += mediaAluno[i];
            }

            mediaGeral /= 5;

            for (int i = 0; i < 5; i++)
            {
                lsbNotas.Items.Add($"Aluno {i + 1}; Nota Professor 1: {notas[i, 0]:F2}; Nota Professor 2: {notas[i, 1]:F2}; Nota Professor 3: {notas[i, 2]:F2}; Média: {mediaAluno[i]:F2}");
            }
            lsbNotas.Items.Add("----------------------------------------------------");
            lsbNotas.Items.Add($"Média Geral Alunos: {mediaGeral:F2}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lsbNotas.Items.Clear();
        }
    }
}
