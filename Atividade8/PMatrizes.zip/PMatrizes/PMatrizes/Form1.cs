﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            string auxiliar;
            int[] vetor = new int[20];

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o numero", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Dado invalido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            auxiliar = "";
            auxiliar = String.Join("\n", vetor);

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            ArrayList alunos = new ArrayList {"Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            alunos.Remove("Otávio");

            foreach (string s in alunos) 
            {
                auxiliar += s + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[] media = new double[20];
            double[,] notas = new double[20,3];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota{j + 1}:", $"Aluno {i + 1}");

                    if (!Double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota Invalida");
                        j--;
                    }
                    else
                    {
                        media[i] += notas[i, j];
                    }
                }
                media[i] /= 3;
            }

            for (int i = 0; i < 20; i++)
            {
                auxiliar += $"\nAluno {i + 1}: Média: {media[i]:F2}";
            }

            MessageBox.Show(auxiliar);
        }
    }
}
