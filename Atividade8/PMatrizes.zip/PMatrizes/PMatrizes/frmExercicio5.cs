﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar;
            string[,] respostas = new string[2,10];
            string[] gabarito = {"A", "B", "C", "D", "E", "A", "B", "C", "D", "E"};

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta da {j+1}º Questao: ", "Gabarito");
                    auxiliar = auxiliar.ToUpper();
                    
                    if (auxiliar != "A" && auxiliar != "B" && auxiliar != "C" && auxiliar != "D" && auxiliar != "E")
                    {
                        MessageBox.Show("Alternativa Inválida");
                        j--;
                    }

                    else
                    {
                        respostas[i, j] = auxiliar;
                    }
                }
            }

            lbLista.Items.Clear();
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (respostas[i,j] == gabarito[j].ToString())
                    {
                        lbLista.Items.Add("O aluno " + (i+1) + ": acertou a questão " + (j+1) + ": era " + gabarito[j] + ", escolheu " + respostas[i, j]);
                    }
                    else
                    {
                        lbLista.Items.Add("O aluno " + (i + 1) + ": errou a questão " + (j + 1) + ": era " + gabarito[j] + ", escolheu " + respostas[i, j]);
                    }
                }
            }
        }
    }
}
