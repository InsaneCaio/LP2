﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar;
            string[,] questoes = new string[2,10];
            char[] gabarito = {'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E'};

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta da {j+1}º Questao: ", "Gabarito");
                    
                    if (auxiliar != "A" || auxiliar != "B" || auxiliar != "C" || auxiliar != "D" || auxiliar != "E")
                    {
                        MessageBox.Show("Alternativa Incorreta");
                        j--;
                    }

                    else
                    {
                        questoes[i, j] = auxiliar;
                    }
                }
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (questoes[i,j] == gabarito[j].ToString())
                    {
                        lbLista.Items.Add("O aluno " + i + 1 + ": acertou a questão " + j + 1 + ": era " + gabarito[j] + ", escolheu " + questoes[i, j]);
                    }
                }
            }
        }
    }
}
