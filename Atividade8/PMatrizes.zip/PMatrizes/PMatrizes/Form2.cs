﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] pessoas = new string[10];
            int[] numCarac = new int[10];

            lbLista.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome da {i+1}ºpessoa: ", "Entrada de Dados");

                if (auxiliar == "" || auxiliar == null)
                {
                    MessageBox.Show("Nome invalido");
                    i--;
                }
                else
                {
                    foreach (char c in auxiliar)
                    {
                        if (c != ' ')
                        {
                            numCarac[i]++;
                        }
                    }

                    if (numCarac[i] == 0)
                    {
                        MessageBox.Show("Nome invalido");
                        i--;
                    }
                    else
                    {
                        pessoas[i] = auxiliar;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                auxiliar = numCarac[i].ToString();
                lbLista.Items.Add("o nome: " + pessoas[i] + " tem " + auxiliar + " caracteres");
            }
        }
    }
}
