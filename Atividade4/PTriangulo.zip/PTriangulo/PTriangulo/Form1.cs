﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double a, b, c;

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
                                        
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out a) || a <= 0)
            {
                MessageBox.Show("Valor A inválido");
                txtValorA.Focus();
            }

            if (!Double.TryParse(txtValorB.Text, out b) || b <= 0)
            {
                MessageBox.Show("Valor B inválido");
                txtValorB.Focus();
            }

            if (!Double.TryParse(txtValorC.Text, out c) || c <= 0)
            {
                MessageBox.Show("Valor C inválido");
                txtValorC.Focus();
            }

            if (!(Math.Abs(b - c) < a && a < b + c) && !(Math.Abs(a - c) < b && b < a + c) && !(Math.Abs(a - b) < c && c < a + b))
                MessageBox.Show("Um ou mais desses valores não seguem a regra de formação");
            else
            {
                if (a == b && b == c)
                    txtClasse.Text = "Equilátero";
                else if (a == b || b == c || a == c)
                    txtClasse.Text = "Isóceles";
                else
                    txtClasse.Text = "Escaleno";
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        
    }
}
