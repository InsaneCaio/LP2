﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtValorA = new System.Windows.Forms.TextBox();
            this.btnExecutar = new System.Windows.Forms.Button();
            this.lblValorA = new System.Windows.Forms.Label();
            this.lblValorB = new System.Windows.Forms.Label();
            this.lblValorC = new System.Windows.Forms.Label();
            this.txtValorB = new System.Windows.Forms.TextBox();
            this.txtValorC = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblClasse = new System.Windows.Forms.Label();
            this.txtClasse = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtValorA
            // 
            this.txtValorA.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.txtValorA.Location = new System.Drawing.Point(224, 42);
            this.txtValorA.Name = "txtValorA";
            this.txtValorA.Size = new System.Drawing.Size(200, 44);
            this.txtValorA.TabIndex = 0;
            this.txtValorA.Validated += new System.EventHandler(this.txtValorA_Validated);
            // 
            // btnExecutar
            // 
            this.btnExecutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.btnExecutar.Location = new System.Drawing.Point(149, 319);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(175, 97);
            this.btnExecutar.TabIndex = 3;
            this.btnExecutar.Text = "Executar";
            this.btnExecutar.UseVisualStyleBackColor = true;
            this.btnExecutar.Click += new System.EventHandler(this.btnExecutar_Click);
            // 
            // lblValorA
            // 
            this.lblValorA.AutoSize = true;
            this.lblValorA.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblValorA.Location = new System.Drawing.Point(62, 45);
            this.lblValorA.Name = "lblValorA";
            this.lblValorA.Size = new System.Drawing.Size(124, 37);
            this.lblValorA.TabIndex = 2;
            this.lblValorA.Text = "Valor A";
            // 
            // lblValorB
            // 
            this.lblValorB.AutoSize = true;
            this.lblValorB.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblValorB.Location = new System.Drawing.Point(62, 131);
            this.lblValorB.Name = "lblValorB";
            this.lblValorB.Size = new System.Drawing.Size(123, 37);
            this.lblValorB.TabIndex = 3;
            this.lblValorB.Text = "Valor B";
            // 
            // lblValorC
            // 
            this.lblValorC.AutoSize = true;
            this.lblValorC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblValorC.Location = new System.Drawing.Point(62, 213);
            this.lblValorC.Name = "lblValorC";
            this.lblValorC.Size = new System.Drawing.Size(125, 37);
            this.lblValorC.TabIndex = 4;
            this.lblValorC.Text = "Valor C";
            // 
            // txtValorB
            // 
            this.txtValorB.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.txtValorB.Location = new System.Drawing.Point(224, 128);
            this.txtValorB.Name = "txtValorB";
            this.txtValorB.Size = new System.Drawing.Size(200, 44);
            this.txtValorB.TabIndex = 1;
            this.txtValorB.Validated += new System.EventHandler(this.txtValorB_Validated);
            // 
            // txtValorC
            // 
            this.txtValorC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.txtValorC.Location = new System.Drawing.Point(224, 210);
            this.txtValorC.Name = "txtValorC";
            this.txtValorC.Size = new System.Drawing.Size(200, 44);
            this.txtValorC.TabIndex = 2;
            this.txtValorC.Validated += new System.EventHandler(this.txtValorC_Validated);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.btnSair.Location = new System.Drawing.Point(447, 319);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(175, 97);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblClasse.Location = new System.Drawing.Point(513, 101);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(206, 37);
            this.lblClasse.TabIndex = 8;
            this.lblClasse.Text = "Classificação";
            // 
            // txtClasse
            // 
            this.txtClasse.Enabled = false;
            this.txtClasse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.txtClasse.Location = new System.Drawing.Point(513, 165);
            this.txtClasse.Name = "txtClasse";
            this.txtClasse.Size = new System.Drawing.Size(206, 44);
            this.txtClasse.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtClasse);
            this.Controls.Add(this.lblClasse);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtValorC);
            this.Controls.Add(this.txtValorB);
            this.Controls.Add(this.lblValorC);
            this.Controls.Add(this.lblValorB);
            this.Controls.Add(this.lblValorA);
            this.Controls.Add(this.btnExecutar);
            this.Controls.Add(this.txtValorA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValorA;
        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.Label lblValorA;
        private System.Windows.Forms.Label lblValorB;
        private System.Windows.Forms.Label lblValorC;
        private System.Windows.Forms.TextBox txtValorB;
        private System.Windows.Forms.TextBox txtValorC;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblClasse;
        private System.Windows.Forms.TextBox txtClasse;
    }
}

