﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double res, num1, num2;

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out num2))
            {
                errorProvider2.SetError(txtNumero2, "Numero 2 Inválido!");
                txtNumero2.Focus();
            }
            else
            {
                errorProvider2.SetError(txtNumero2, "");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            res = num1 + num2;
            txtResultado.Text = res.ToString("F2");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            res = num1 - num2;
            txtResultado.Text = res.ToString("F2");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            res = num1 * num2;
            txtResultado.Text = res.ToString("F2");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                errorProvider2.SetError(txtNumero2, "Não pode dividir por 0");
                txtNumero2.Focus();
            }
            else
            {
                res = num1 / num2;
                txtResultado.Text = res.ToString("F2");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair? Vou quebrar suas pernas",
                                    "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out num1))
            {
                errorProvider1.SetError(txtNumero1, "Numero 1 Inválido!");
                txtNumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNumero1, "");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
